<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/bootstrap.js"></script>
<script src="../assets/js/custom.js"></script>
<script src="https://www.devcode.pt/assets/libs/fontawesome/js/all.min.js"></script>