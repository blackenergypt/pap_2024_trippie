<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="admin_dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Site</div>
                            <a class="nav-link" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Página Principal
                            </a>
                            <a class="nav-link" href="price.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Escolher Produto
                            </a>
                            <div class="sb-sidenav-menu-heading">Área de Cliente</div>

                            <a class="nav-link" href="produtos.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Produtos
                            </a>
                        </div>
                    </div>
                </nav>