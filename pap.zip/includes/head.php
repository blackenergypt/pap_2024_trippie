<link rel="icon" href="../assets/images/lock.png" type="image/png">
<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
<link href="../assets/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link href="../assets/css/style.css" rel="stylesheet">
<link href="../assets/css/responsive.css" rel="stylesheet">
<link rel="stylesheet" href="https://www.devcode.pt/assets/libs/fontawesome/css/all.min.css">